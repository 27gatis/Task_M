
// Activates buttons for movement
$(document).ready(function () {
    $("#button-sign-up").click(function () {
        $("#slider").animate({
            right: "+=423px"
        }, 700);
    });
});

$(document).ready(function () {
    $("#button-login").click(function () {
        $("#slider").animate({
            right: "-=423px"
        }, 700);
    });
});




// Hides and shows form attributes
$(document).ready(function () {
    $("#button-sign-up").click(function () {
        $('#hider').hide().show('slow');
        $(".user").fadeIn('slow');
        $(".to-hide").hide();
        $('.to-change').html('Sign up', 'slow');

    });

});


$(document).ready(function () {
    $("#button-login").click(function () {
        $('#hider').hide().show('slow');
        $(".user").hide();
        $(".to-hide").fadeIn('slow');
        $('.to-change').html('Login', 'slow');
    });

});




// Changes active field background
$(document).ready(function () {
    $(document).on('mousemove', function (e) {
        $('#cursor').css({
            left: e.pageX,
            top: e.pageY
        });
    })
});

